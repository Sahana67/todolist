import { useState } from 'react'
import './App.css'

function App() {
  const [todos, setTodos] = useState([])
  const [inputValue, setInputValue] = useState('')
  const [editId, setEditId] = useState(null)

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!inputValue.trim()) return

    if (editId !== null) {
      setTodos(todos.map(todo => 
        todo.id === editId ? { ...todo, text: inputValue } : todo
      ))
      setEditId(null)
    } else {
      setTodos([...todos, { id: Date.now(), text: inputValue, completed: false }])
    }
    setInputValue('')
  }

  const handleDelete = (id) => {
    setTodos(todos.filter(todo => todo.id !== id))
  }

  const handleEdit = (todo) => {
    setEditId(todo.id)
    setInputValue(todo.text)
  }

  const toggleComplete = (id) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ))
  }

  return (
    
<div className="todo-container">
      <h1>Todo List</h1>
      <form onSubmit={handleSubmit} className="todo-form">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Add a new todo..."
          className="todo-input"
        />
        <button type="submit" className="todo-button">
          {editId !== null ? 'Update' : 'Add'}
        </button>
      </form>
      <ul className="todo-list">
        {todos.map(todo => (
          <li key={todo.id} className={`todo-item ${todo.completed ? 'completed' : ''}`}>
            <input
              type="checkbox"
              checked={todo.completed}
              onChange={() => toggleComplete(todo.id)}
            />
            <span>{todo.text}</span>
            <div className="todo-actions">
              <button onClick={() => handleEdit(todo)} className="edit-btn">
                Edit
              </button>
              <button onClick={() => handleDelete(todo.id)} className="delete-btn">
                Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
    
    
  )
}

export default App
